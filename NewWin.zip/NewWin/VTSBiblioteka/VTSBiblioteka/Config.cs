﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VTSBiblioteka
{
    class Config
    {
        public string servername = "localhost";
        public string username = "root";
        public string password = "";
        public string db = "vts_biblioteka";
    }
}
